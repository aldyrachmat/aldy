set FLASK_APP=printer.py
Flask run --port = 8000
