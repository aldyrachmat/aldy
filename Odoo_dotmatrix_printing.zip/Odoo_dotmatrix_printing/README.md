# Odoo-dotmarix-printing
Custom addons for dotmatrix printing on Odoo15
