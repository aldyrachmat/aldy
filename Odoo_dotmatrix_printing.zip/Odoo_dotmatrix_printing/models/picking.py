import time
import json

from odoo import api, fields, models, _
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)

class picking(models.Model):
    _name = 'stock.picking'
    _inherit = 'stock.picking'

    printer_data = fields.Char("Printer Data", readonly=True)

    def action_refresh_printer_data(self):
        do_name = self.picking_type_id.name.ljust(10) +' :'.ljust(3) + self.name.rjust(11) if self.name else ''
        stripe_space = ''.rjust(80, '-')
        do_cust = self.partner_id.display_name.ljust(50) if self.partner_id else ''.ljust(50)
        do_date = ' Tanggal : '.rjust(10 ) + str(self.scheduled_date).rjust(13) if self.scheduled_date else ''.ljust(13)
        #do_address = self.partner_id.display_name.ljust(55) if self.partner_id else ''.ljust(55)
        #cashier = 'Kasir'.rjust(11) + ':'.rjust(3) + self.user_id.name if self.user_id else ''.ljust(20)
        do_street = self.partner_id.street[:55].ljust(55) if self.partner_id.street else ''.ljust(55)
        do_street2 = self.partner_id.street2[:52].ljust(52) if self.partner_id.street2 else ''.ljust(52)
        do_kota = self.partner_id.city[:16].ljust(16) if self.partner_id.city else ''.ljust(16)
        do_mobile = ''.rjust(1) + self.partner_id.mobile[:12].ljust(12) if self.partner_id.mobile else ''.ljust(12)
        do_phone = 'Tlp.'.rjust(1) + self.partner_id.phone[:12].ljust(12) if self.partner_id.phone else ''.ljust(12)

        number = '    Code'.ljust(12)
        product_name = 'Jenis Material'.ljust(46)
        qty = 'Qty     Packaging'.ljust(15)

        #do_opr =  self.picking_type_id.name.rjust(15)
        do_source = 'Source Document :'.rjust(15) + self.origin.rjust(8)
        do_backor = 'Back Order of:'.rjust(40) + self.backorder_id.name if self.backorder_id else ''

        data_list = []

        for i in range(len(self.move_ids_without_package)):
            data_list.append([str(i + 1) + '.'.ljust(2),
                              self.move_ids_without_package[i].name[:48].ljust(48)
                                    if self.move_ids_without_package[i].name else ''.ljust(48),
                              str(int(self.move_ids_without_package[i].quantity_done)).rjust(6) + ' '
                                    if self.move_ids_without_package[i].quantity_done else''.ljust(6),

                              self.move_ids_without_package[i].product_uom.display_name[:10].ljust(10) [:4].rjust(4) if
                                   self.move_ids_without_package[i].product_uom.display_name[:10].ljust(10) else
                                   ''.rjust(4),

                              "{:4,.0f}".format(int(self.move_ids_without_package[i].quantity_done)/
                                    int(self.move_ids_without_package[i].product_packaging_id.qty)).rjust(5) + ' '+
                                    self.move_ids_without_package[i].product_packaging_id.display_name.ljust(12)
                                    if self.move_ids_without_package[i].product_packaging_id.qty else ''.rjust(0),

                              ])

        sign = 'Penerima'.rjust(12) + ''.ljust(8) + 'Expedisi'.rjust(12) + ''.ljust(4) + 'Gudang'.rjust(12) + \
               ''.ljust(6) + ''.ljust(8) + 'Mengetahui'.rjust(10)

        k = 1
        while k < (11 - i):
            data_list.append([''.ljust(0)]),
            k += 1

        data = '\n' + do_name + '\n' + stripe_space + '\n' + do_cust + do_date + '\n' + \
                do_street +  do_source + '\n' + do_street2.strip() + ' ' + do_kota +  '\n'+ \
                do_phone + do_mobile + '\n' + \
                stripe_space + '\n' + number + product_name + qty  + '\n' + stripe_space +'\n'

        for count, value in enumerate(data_list):
            data2 = ''.join(value)
            data = data + data2 + '\n'

        data = data + stripe_space + '\n' + sign + '\n\n\n\n\n\n\n\n'

        self.printer_data = data

    def dummy(self):
        pass


    def action_post(self):
        res = super(picking, self).action_post()
        self.action_refresh_printer_data()
        return res

