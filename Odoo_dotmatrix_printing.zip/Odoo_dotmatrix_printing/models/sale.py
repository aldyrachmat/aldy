import time
import json

from odoo import api, fields, models, _
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)

class sale(models.Model):
    _name = 'sale.order'
    _inherit = 'sale.order'

    printer_data = fields.Char("Printer Data", readonly=True)

    def action_refresh_printer_data(self):
        company_name = self.env.company.name.ljust(45) if self.env.company.name else "My Company".ljust(45)
        address = self.env.company.street.ljust(65) if self.env.company.street else "Address".ljust(65)
        phone = self.env.company.phone if self.env.company.phone else "Phone"
        mobile = self.env.company.mobile if self.env.company.mobile else "Mobile"
        contact = str('Telp. ' + phone + 'Hp. ' + mobile).ljust(64)

        invoice_name = 'No.Sales Order'.rjust(13)+ ': '.rjust(4) + self.name.rjust(13) if self.name else ''
        stripe_space = ''.rjust(80, '-')
        invoice_bill = self.partner_id.display_name.ljust(50) if self.partner_id else ''.ljust(50)
        date = ' Tanggal'.rjust(7) + ' : '.rjust(4) + str(self.date_order)[:10].rjust(13) if self.date_order else ''.ljust(13)
        invoice_address = self.partner_id.display_name.ljust(55) if self.partner_id else ''.ljust(55)
        cashier = 'Kasir'.rjust(11) + ':'.rjust(3) + self.user_id.name if self.user_id else ''.ljust(20)
        street = self.partner_id.street[:55].ljust(55) if self.partner_id.street else ''.ljust(55)
        street2 = self.partner_id.street2[:52].ljust(52) if self.partner_id.street2 else ''.ljust(52)
        kota = self.partner_id.city[:16].ljust(16) if self.partner_id.city else ''.ljust(16)
        mobile = ''.rjust(1) + self.partner_id.mobile[:12].ljust(12) if self.partner_id.mobile else ''.ljust(12)
        phone = 'Tlp.'.rjust(1) + self.partner_id.phone[:12].ljust(12) if self.partner_id.phone else ''.ljust(12)

        pembayaran = 'Pembayaran'.rjust(11) + ':'.rjust(3) + self.payment_term_id.display_name .rjust(14)
        jatuh_tempo = 'Jatuh Tempo' .rjust(18) + ':'.rjust(3)

        number = 'Code'.ljust(9)
        product_name = 'Jenis Material'.ljust(31)
        qty = 'Qty'.ljust(0)
        price = 'Harga'.rjust(12)
        mdisc = 'Disc(%)'.rjust(12)
        subtotal = 'SubTotal'.rjust(13)

        data_list = []
        ttlorder = 0

        for i in range(len(self.order_line)):
          
            data_list.append([self.order_line[i].product_id.display_name[9:].ljust(36)
                                if self.order_line[i].name else ''.ljust(36),
                                
                                str(int(self.order_line[i].product_packaging_qty)).rjust(6)
                                    if self.order_line[i].product_packaging_qty else 
                                    str(int(self.order_line[i].product_uom_qty)).rjust(6)
                                    if self.order_line[i].product_uom_qty else ''.rjust(6),    
                                
                                self.order_line[i].product_packaging_id.display_name[:4].ljust(4)
                                    if self.order_line[i].product_packaging_id.display_name else                           
                                    self.order_line[i].product_uom.display_name[:4].ljust(4)
                                    if self.order_line[i].product_uom.display_name else ''.ljust(4), 
                                
                                "{:4,.0f}".format(self.order_line[i].price_unit).rjust(11)
                                    if self.order_line[i].price_unit else ''.ljust(11),

                                str(self.order_line[i].multi_discount)[:9].rjust(10)
                                    if str(self.order_line[i].multi_discount) else ''.ljust(10),

                                "{:4,.0f}".format(self.order_line[i].price_total).rjust(13) if
                                    self.order_line[i].price_total else ''.ljust(13)]),

            ttlorder = ttlorder + self.order_line[i].price_total

        total = 'Total (include PPN) :'.rjust(63)+ "{:4,.0f}".format(ttlorder).rjust(17)
        ppn = 'PPN :'.rjust(63) + "{:4,.0f}".format((ttlorder)*11/111).rjust(17)
        total_order= 'Total Order :'.rjust(63) + "{:4,.0f}".format(ttlorder).rjust(17)

        sign = 'Penerima'.rjust(10) + ''.ljust(6) + 'Expedisi'.rjust(10) + ''.ljust(6) + 'Gudang'.rjust(10) + \
               ''.ljust(6) + 'Administrasi'.rjust(10) + ''.ljust(6) + 'Mengetahui'.rjust(10)

        k = 1
        while k < (10-i):
            data_list.append([''.ljust(0)]),
            k += 1

        data = '\n' + invoice_bill + invoice_name + '\n'+\
               street + date +'\n' + \
               street2 + pembayaran + '\n' + \
               kota + phone + mobile + jatuh_tempo + '\n' +\
               stripe_space + '\n' + \
               number + product_name + qty + price + mdisc + subtotal + '\n' + stripe_space + '\n'

        for count, value in enumerate(data_list):
            data2 = ''.join(value)
            data = data + data2 + '\n'

        data = data + stripe_space + '\n' + total + '\n'+ ppn + '\n'+ total_order + '\n' + stripe_space + '\n' + sign

        self.printer_data = data

    def dummy(self):
        pass

    def action_post(self):
        res = super(sale, self).action_post()
        self.action_refresh_printer_data()
        return res
