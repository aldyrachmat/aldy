import time
import json

from odoo import api, fields, models, _
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)

class invoice(models.Model):
    _name = 'account.move'
    _inherit = 'account.move'

    printer_data = fields.Char("Printer Data", readonly=True)

    def action_refresh_printer_data(self):
        company_name = self.env.company.name.ljust(45) if self.env.company.name else "My Company".ljust(45)
        address = self.env.company.street.ljust(65) if self.env.company.street else "Address".ljust(65)
        phone = self.env.company.phone if self.env.company.phone else "Phone"
        mobile = self.env.company.mobile if self.env.company.mobile else "Mobile"
        contact = str('Telp. ' + phone + 'Hp. ' + mobile).ljust(64)

        if self.name.find('V') > 0:
            invoice_name = ''.rjust(17) + self.name.rjust(13) if self.name else ''
            stripe_space = ''.rjust(80, ' ')
            date = ''.rjust(16) + str(self.invoice_date).rjust(11)if self.invoice_date else ''.rjust(11)
        else:
            invoice_name = 'No.invoice'.rjust(13)+ ': '.rjust(4) + self.name.rjust(13) if self.name else ''
            stripe_space = ''.rjust(80, '-')
            date = ' Tanggal'.rjust(10) + ' :'.rjust(6) + str(self.invoice_date).rjust(
                11) if self.invoice_date else ''.rjust(11)

        invoice_bill = self.partner_id.display_name.ljust(50) if self.partner_id else ''.ljust(50)
        invoice_address = self.partner_id.display_name.ljust(55) if self.partner_id else ''.ljust(55)
        cashier = 'Kasir'.rjust(11) + ':'.rjust(3) + self.user_id.name if self.user_id else ''.ljust(20)
        street = self.partner_id.street[:50].ljust(50) if self.partner_id.street else ''.ljust(50)
        street2 = self.partner_id.street2 [:49].ljust(49)+' ' if self.partner_id.street2 else ''.ljust(50)
        kota = self.partner_id.city[:30].ljust(30) if self.partner_id.city else ''.ljust(30)
        mobile = ''.rjust(1) + self.partner_id.mobile[:13].ljust(13) if self.partner_id.mobile else ''.ljust(0)
        phone = 'Tlp/Mobile '.ljust(12) + self.partner_id.phone[:10].ljust(10) if self.partner_id.phone else ''.ljust(0)

        kota = (street2.strip() + ' ' + kota.strip()).lstrip().ljust(40)
        phone = (phone + mobile).ljust(35)

        if self.name.find('V') > 0:
            pembayaran = self.invoice_payment_term_id.display_name.rjust(34)
            jatuh_tempo = ''
            number = ''.rjust(80)
            sign = ''.rjust(80)
            m = 9
        else:
            m = 11
            pembayaran = 'Pembayaran'.rjust(23) + ':'.rjust(3)
            jatuh_tempo = 'Jatuh Tempo'.rjust(28) + ':'.rjust(2)
                          #+ self.invoice_payment_term_id.display_name.rjust(8)

            #number = 'Code'.ljust(9)
            product_name = 'Jenis Material'.ljust(36)
            qty = 'Qty'.rjust(10)
            price = 'Harga'.rjust(11)
            mdisc = 'Disc(%)'.rjust(10)
            subtotal = 'SubTotal'.rjust(13)
            number = product_name + qty + price + mdisc + subtotal
            sign = 'Penerima'.rjust(8) + ''.ljust(8) + 'Expedisi'.rjust(10) + ''.ljust(4) + 'Gudang'.rjust(12) + \
                   ''.ljust(6) + 'Administrasi'.rjust(14) + ''.ljust(8) + 'Mengetahui'.rjust(10)

        data_list = []
        ttlorder = 0
        ppn = '1'

        for i in range(len(self.invoice_line_ids)):
            if self.invoice_line_ids[i].product_id.display_name.find('PPN') > 0: ppn=' '

            #data_list.append([str(i + 1).rjust(2) + '.'.ljust(2),
            data_list.append([self.invoice_line_ids[i].product_id.display_name[9:].ljust(36)
                                if self.invoice_line_ids[i].product_id.display_name else '' .ljust(36),
                            str(int(self.invoice_line_ids[i].quantity)).rjust(6)
                                if self.invoice_line_ids[i].quantity else ''.rjust(6),
                            self.invoice_line_ids[i].product_uom_id.display_name[:4].rjust(4)
                                if self.invoice_line_ids[i].product_uom_id.display_name else ''.rjust(4),
                            "{:4,.0f}".format(self.invoice_line_ids[i].price_unit).rjust(11)
                                if self.invoice_line_ids[i].price_unit else ''.rjust(11),
                            str(self.invoice_line_ids[i].multi_discount)[:10].rjust(10)
                                if str(self.invoice_line_ids[i].multi_discount) else ''.rjust(10),
                            "{:4,.0f}".format(self.invoice_line_ids[i].price_total).rjust(13) if
                                self.invoice_line_ids[i].price_total else ''.ljust(13)])

            ttlorder = ttlorder + self.invoice_line_ids[i].price_total

        total = 'Total (include PPN) :'.rjust(67) + "{:4,.0f}".format(ttlorder).rjust(13)

        if ppn != ' ': ppn = 'PPN :'.rjust(67) + "{:4,.0f}".format((ttlorder) * 11 / 111).rjust(13)

        paid = 'Bayar / DP :'.rjust(67) + "{:4,.0f}".format(json.loads(self.invoice_payments_widget)['content']
                [0]['amount'] if self.invoice_payments_widget != 'false' else 0).rjust(13) \
                if self.invoice_payments_widget != False else '{}'

        amount_residual =   'Total Invoice :'.rjust(67) + "{:4,.0f}".format(self.amount_residual).rjust(13)


        k = 1
        while k <= (m-i):
            data_list.append([''.ljust(2)]),
            k += 1
        
        if self.name.find('V') > 0:
            data = '\n\n' + invoice_bill + invoice_name
        else:
            data = invoice_bill + invoice_name
        
        data = data + '\n'+\
               street + date +'\n' + \
               kota  + pembayaran + '\n' + \
               phone +  jatuh_tempo + '\n' + \
               stripe_space + '\n' + \
               number + '\n' + \
               stripe_space + '\n'

        for count, value in enumerate(data_list):
            data2 = ''.join(value)
            data = data + data2 + '\n'

        data = data + stripe_space + '\n' + total + '\n' + ppn + '\n' + paid + '\n' + amount_residual +'\n' \
               + stripe_space + '\n'+ sign + '\n\n\n\n\n\n\n\n'

        #conde = 'Chr(27).Chr(33).Chr(4)'

        #data = conde + data

        self.printer_data = data

    def dummy(self):
        pass

    def action_post(self):
        res = super(invoice, self).action_post()
        self.action_refresh_printer_data()
        return res
